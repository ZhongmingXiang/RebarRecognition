clear all
close all
clc
warning off



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
Zhou, X., Chen, H., & Li, J., An automatic GPR B-scan image interpreting model.
 IEEE Transactions on Geoscience and Remote Sensing. 56(6) (2018) pp.3398-3412. https://doi.org/10.1109/TGRS.2018.2799586
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fileFolder=fullfile('RegularData'); 
dirOutput=dir(fullfile(fileFolder,'*.jpg')); 
fileNames={dirOutput.name};
for iFile = 1:length(fileNames)
file = strcat('RegularData\',fileNames{iFile});


%% load GPR data
% file='gprMax_output\threedModeling\demoB1010009_744.jpg';

% file='..\submission\RebarRecognition\results\onsiteData\15.jpg';
I = imread(file);
% for mmmm=1
% gray scale
% Itc = imresize(I(:,:,1),[512,512]);
Itc = I(:,:,1);
% figure('name', 'preprocess', 'visible','on');
% subplot(221)
% imshow(Itc);




%% Preprocessing Method
% A. Thresholding Algorithm Based on Gradient Information
% longitudinal gradient Dy(x,y)
Dy = zeros(size(Itc));
for i=2:length(Itc(:,1))-1
    Dy(i,:) = (Itc(i+1,:)-Itc(i-1,:))/2;
end


% subplot(222)
% imshow(Dy);


% threshold
% the mean of the gray values of all P(x, y) values that satisfie
tempItc = Itc;
tempItc(Dy==0)=0; % 
thrsd = mean(mean(tempItc));

% convert to binary image
ItcThrd = Itc;
ItcThrd(ItcThrd<thrsd)=1;
ItcThrd(ItcThrd>=thrsd)=0;
ItcThrd(ItcThrd==1)=255;
BWImage = im2bw(ItcThrd);
% subplot(223)
% imshow(BWImage);

% B. Opening and Closing Operations
% closing
BWImage_C = imclose(BWImage,strel('disk', 3));
% opening
BWImage_O = imopen(BWImage_C, strel('disk', 2)); % open operation
% subplot(224)
% imshow(BWImage_O);



%% Open-Scan Clustering Algorithm (OSCA)

% cluster 
bwLabel = bwlabel(BWImage_O);  % each cluster has a specific label
% figure
% subplot(335)
% imshow(bwLabel)

generalLabel = 1;
pcBW = zeros(size(bwLabel)); % an empty image to store the final results

% cluster label
uniqueIdx = unique(unique(bwLabel));
uniqueIdx(uniqueIdx==0)=[];
for iCluster=1:length(uniqueIdx)
    
    
    
    % a temp image stored a specific label
    tempImage = bwLabel;
    tempImage(tempImage~=uniqueIdx(iCluster))=0;
%     figure
%     imshow(tempImage);
    
    % [XL XR] of each point segment
    XLXR = []; % store the segment boundaries
    for i=1:length(tempImage(:,1))
        tempLine = tempImage(i,:); % one line
        if sum(tempLine)~=0
            
            % none-zero units
            ii = zeros(size(tempLine));
            jj = tempLine > 0;
            ii(strfind([0,jj(:)'],[0 1])) = 1;
            idx = cumsum(ii).*jj;
            sIdx = unique(idx);
            sIdx(sIdx==0)=[];
            % segment boundary 
            for j=1:length(sIdx)
                poistion = find(idx == sIdx(j));
                XLXR = [XLXR; i poistion(1) poistion(end)];
            end            
        end
    end
    
    
    
    
    % find the lines that have two point segments
    [GC,GR] = groupcounts(XLXR(:,1));    
    tailsLineNumber = find(GC~=1);
    if ~isempty(tailsLineNumber)
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
        % define the downward opening and upward opening
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        clear downOpen  % a cell to store the downopening
        clear upOpen    % a cell to store the upopening
        k1 = 1;
        k2 = 1;        
        for i=1:length(tailsLineNumber)
            % downopening
            if tailsLineNumber(i)~=1
                upIdx = find(XLXR(:,1) == GR(tailsLineNumber(i)-1));     % next up line
                currentIdx = find(XLXR(:,1) == GR(tailsLineNumber(i)));  % current line
                for mm = 1:length(currentIdx)-1               % all combinations of segments in current line
                    for nn = mm+1:length(currentIdx)
                        for j=1:length(upIdx)                 % all segments in next up line
                            xUP = XLXR(upIdx(j),2:end);       % left and right boundaries of segment
                            x1 = XLXR(currentIdx(mm),2:end);
                            x2 = XLXR(currentIdx(nn),2:end);
                            % check if it's downopening
                            if ((xUP(1)<=x1(2) && xUP(2)>=x1(2)) || (xUP(1)<=x1(1) && xUP(2)>=x1(1))) && ((xUP(1)<=x2(2) && xUP(2)>=x2(2)) || (xUP(1)<=x2(1) && xUP(2)>=x2(1)))
                                downOpen{k1,1} = [XLXR(upIdx(j),:)
                                    XLXR(currentIdx(mm),:)
                                    XLXR(currentIdx(nn),:)];   % store the downopening
                                k1 = k1+1;
                            end
                        end
                    end
                end            
            end
            % upopening
            if tailsLineNumber(i)~=length(GR)
                downIdx = find(XLXR(:,1) == GR(tailsLineNumber(i)+1));   % next down line
                currentIdx = find(XLXR(:,1) == GR(tailsLineNumber(i)));  % current line
                for mm = 1:length(currentIdx)-1                % all combinations of segments in current line
                    for nn = mm+1:length(currentIdx)
                        for j=1:length(downIdx)                % all segments in next down line
                            xDW = XLXR(downIdx(j),2:end);      % left and right boundaries of segment
                            x1 = XLXR(currentIdx(mm),2:end);
                            x2 = XLXR(currentIdx(nn),2:end);
                            % check if it's upopening
                            if ((xDW(1)<=x1(2) && xDW(2)>=x1(2)) || (xDW(1)<=x1(1) && xDW(2)>=x1(1))) && ((xDW(1)<=x2(2) && xDW(2)>=x2(2)) || (xDW(1)<=x2(1) && xDW(2)>=x2(1)))
                                upOpen{k2,1} = [XLXR(downIdx(j),:)
                                    XLXR(currentIdx(mm),:)
                                    XLXR(currentIdx(nn),:)];    % store the upopening
                                k2 = k2+1;
                            end
                        end
                    end
                end            
            end
        end
        
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % determine downopening tops, upopening bottoms, the intersection of downopening and upopening
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%% label value denotation %%%%%%%%%%%%%%%%%%%
        % label 1000~1999 for downopening
        % label 2000  for upopening (v shape is also assined with 2000)
        % label 3000  for intersection of two hyperbolas of Lambada shape
        % label 4000~ for intersection of two hyperbolas of X shape
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if k1~=1 && k2~=1
            % downopening tops
            for i=1:k1-1
                d = downOpen{i,1};
                lineNum = d(1,1);
                tempImage(lineNum,d(1,2):d(1,3)) = 1000+i; % assign a label to current opening
                tempRange = [d(1,2) d(1,3)];
                lineNum = lineNum -1;  % move up
                ck = 2;  % stop looping if a opening is found
                while sum(ismember(XLXR(:,1),lineNum)) && ck == 2
                    ck = 1;
                    tI = find(XLXR(:,1) == lineNum);
                    for itI = 1:length(tI)                                                
                        x = XLXR(tI(itI),2:end);
                        if x(1)>=tempRange(1) && x(2)<=tempRange(2)
                            tempImage(lineNum,x(1):x(2)) = 1000+i; % assign a label to current opening
                            tempRange = x;
                            ck = 2;
                            break;
                        elseif (x(1)>tempRange(1) && x(1)<tempRange(2) && x(2)>tempRange(2)) || (x(1)<tempRange(1) && x(2)<tempRange(2) && x(2)>tempRange(1))
                            tempImage(lineNum,x(1):x(2)) = 3000;   % separate hyperbolas in Fig.8 in the orginal paper
                        end
                    end                    
                    lineNum = lineNum -1;  % move up
                end                
            end
            % upopening bottoms
            for i=1:k2-1
                d = upOpen{i,1};
                lineNum = d(1,1);
                tempImage(lineNum,d(1,2):d(1,3)) = 2000; % assign a label to current opening
                tempRange = [d(1,2) d(1,3)];
                lineNum = lineNum +1;  % move down
                ck = 2;  % stop looping if a opening is found
                while sum(ismember(XLXR(:,1),lineNum)) && ck == 2
                    ck = 1;
                    tI = find(XLXR(:,1) == lineNum);
                    for itI = 1:length(tI)                                                
                        x = XLXR(tI(itI),2:end);
                        if x(1)>=tempRange(1) && x(2)<=tempRange(2)
                            tempImage(lineNum,x(1):x(2)) = 2000; % assign a label to current opening
                            tempRange = x;
                            ck = 2;
                            break;
                        end
                    end                    
                    lineNum = lineNum +1;  % move down
                end                
            end
            
            % separate hyperbolas in Fig.9 in the orginal paper (X shape)
            nI = tempImage;
            nI(nI<1000) = 0;
            bwNI = bwlabel(nI);
            uniqueBWNI = unique(unique(bwNI));
            uniqueBWNI(uniqueBWNI==0)=[];
            for j=1:length(uniqueBWNI)
                % assgine a label to the intersection of two hyperbolas
                if length(unique(unique(tempImage(bwNI==uniqueBWNI(j)))))>1
                    tempImage(bwNI==uniqueBWNI(j)) = 4000+j;
                end                
            end
            
        elseif k1~=1 && k2==1
            % downopening tops
            for i=1:k1-1
                d = downOpen{i,1};
                lineNum = d(1,1);
                tempImage(lineNum,d(1,2):d(1,3)) = 1000+i; % assign a label to current opening
                tempRange = [d(1,2) d(1,3)];
                lineNum = lineNum -1;  % move up
                ck = 2;  % stop looping if a opening is found
                while sum(ismember(XLXR(:,1),lineNum)) && ck == 2
                    ck = 1;
                    tI = find(XLXR(:,1) == lineNum);
                    for itI = 1:length(tI)                                                
                        x = XLXR(tI(itI),2:end);
                        if x(1)>=tempRange(1) && x(2)<=tempRange(2)
                            tempImage(lineNum,x(1):x(2)) = 1000+i; % assign a label to current opening
                            tempRange = x;
                            ck = 2;
                            break;
                        elseif (x(1)>tempRange(1) && x(1)<tempRange(2) && x(2)>tempRange(2)) || (x(1)<tempRange(1) && x(2)<tempRange(2) && x(2)>tempRange(1))
                            tempImage(lineNum,x(1):x(2)) = 3000;
                        end
                    end                    
                    lineNum = lineNum -1;  % move up
                end                
            end
        elseif k1==1 && k2~=1
            % upopening bottoms
            for i=1:k2-1
                d = upOpen{i,1};
                lineNum = d(1,1);
                tempImage(lineNum,d(1,2):d(1,3)) = 2000; % assign a label to current opening
                tempRange = [d(1,2) d(1,3)];
                lineNum = lineNum +1;  % move down
                ck = 2;  % stop looping if a opening is found
                while sum(ismember(XLXR(:,1),lineNum)) && ck == 2
                    ck = 1;
                    tI = find(XLXR(:,1) == lineNum);
                    for itI = 1:length(tI)                                                
                        x = XLXR(tI(itI),2:end);
                        if x(1)>=tempRange(1) && x(2)<=tempRange(2)
                            tempImage(lineNum,x(1):x(2)) = 2000; % assign a label to current opening
                            tempRange = x;
                            ck = 2;
                            break;
                        end
                    end                    
                    lineNum = lineNum +1;  % move down
                end                
            end
        end
        
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % cluster hyperbolas
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % erose intersections of v shape and Lambada shape
        tempImage(tempImage==2000)=0;
        tempImage(tempImage==3000)=0;
        
        
        
        % extract all downopening
        newI = tempImage;
        newI(newI>=2000) = 0;
        newI(newI<1000) = 0;
        uniqueNEWI = unique(unique(newI));
        uniqueNEWI(uniqueNEWI==0)=[];
        
        % iterate all labels (corresponding to the downopening)
        for i=1:length(uniqueNEWI)
            cId = uniqueNEWI(i); % current label
            % find the bottom of the current labeled top area
            [rows,columns]=find(tempImage == cId);            
            lineNum = max(rows);
            tempRange = [min(columns(find(rows == lineNum))) max(columns(find(rows == lineNum)))];
            lineNum = lineNum+1; % move down
            ck = 2;  % stop looping if no more segment
            while sum(ismember(XLXR(:,1),lineNum)) && ck == 2
                ck =1;
                tI = find(XLXR(:,1) == lineNum);
                
                for itI = 1:length(tI)
                    x = XLXR(tI(itI),2:end);
                    
                    if x(1)<=tempRange(1) && x(2)>=tempRange(1)  && tempImage(lineNum,x(1))<1000 && tempImage(lineNum,x(1))>0
                        tempRange(1) = x(1); % update the boundary
                        tempImage(lineNum,x(1):x(2)) = cId; % assign label
                        ck = 2;
                    elseif x(1)<=tempRange(2) && x(2)>=tempRange(2)  && tempImage(lineNum,x(1))<1000 && tempImage(lineNum,x(1))>0
                        tempRange(2) = x(2); % update the boundary
                        tempImage(lineNum,x(1):x(2)) = cId; % assign label
                        ck = 2;
                    end
                    
                    % if X shape, skip the intersection, but update the boundaries
                    if x(1)<=tempRange(1) && x(2)>=tempRange(1)  && tempImage(lineNum,x(1))>4000
                        tempRange(1) = x(1); % update the boundary
                        ck = 2;
                    elseif x(1)<=tempRange(2) && x(2)>=tempRange(2)  && tempImage(lineNum,x(1))>4000
                        tempRange(2) = x(2); % update the boundary
                        ck = 2;
                    end                    
                end                
                lineNum = lineNum+1; % move down                
            end            
        end
        tempImage(tempImage>4000)=0;
        tempImage(tempImage<1000)=0;
        
%         figure
%         imshow(tempImage)
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % tranfer the labels to the original images
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        uID = unique(unique(tempImage));
        uID(uID==0)=[];
        for i=1:length(uID)
            pcBW(tempImage==uID(i))=generalLabel;
            generalLabel = generalLabel+1;
        end        
        %1        
        
    end
    
    %0
    
end

% figure('name', 'preprocess', 'visible','off');
% subplot(121)
% imshow(pcBW);

% RGB = label2rgb(pcBW, 'spring', 'c', 'shuffle'); % convert to color image
% subplot(122)
% imshow(RGB);


% fit curve
uniqueIdx = unique(unique(pcBW));
uniqueIdx(uniqueIdx==0)=[];
figure('name', 'preprocess', 'visible','on');
imshow(Itc);hold on;
for i=1:length(uniqueIdx)
    [posY,posX]=find(pcBW==uniqueIdx(i));
    
    pointC=[posY,posX];
    p1 = polyfit(pointC(:,2),pointC(:,1),2);
    x1 = linspace(min(pointC(:,2)),max(pointC(:,2)));
    f1 = polyval(p1,x1);
    plot(x1,f1,'r','linewidth',2),hold on;
end

% end
% saveas(gcf,strcat('RegularData_Zhou2018\',fileNames{iFile}))



end






