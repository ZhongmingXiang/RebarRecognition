function blk1 = Lei2019_function(ItF)




figure('name', 'preprocess', 'visible','off');
subplot(331)
imshow(ItF);


I=im2double(ItF);
k=graythresh(I);             
Ib=im2bw(I,k);
%figure
subplot(332)
imshow(Ib);


se1 = strel('square', 2); % a small object with 2 radius
I_close = imclose(Ib, se1); % close operation

BmILogical= imopen(I_close, [0 1 0;1 1 1;1 0 1]); % open operation

subplot(333)
imshow(BmILogical);

BmI = zeros(size(BmILogical));
BmI(BmILogical)=1;

k=2;
for i=1:length(BmI(:,1))    
    if BmI(i,1)==0 && BmI(i,2)==1
        BmI(i,1)=1;
    elseif BmI(i,1)==0 && BmI(i,2)==0
        BmI(i,1)=k;
        k=k+1;
    end
    for j=2:length(BmI(1,:))-1
        if BmI(i,j)==0 && BmI(i,j-1)==1 && BmI(i,j+1)==1
            BmI(i,j)=1;
        elseif BmI(i,j)==0 &&  BmI(i,j-1)==1 && BmI(i,j+1)==0
            BmI(i,j)=k;
            k=k+1;
        elseif BmI(i,j)==0 &&  BmI(i,j-1)~=0
            BmI(i,j)=BmI(i,j-1);
        end
    end
end
BmI(BmI==1)=0;

%figure
subplot(334)
imshow(BmI);










BmID = BmI;
BmIU = BmI;

for idx=1:length(BmID(:,1))-1
    up=unique(BmID(idx,:));
    down=unique(BmID(idx+1,:));
    
    up(up==0)=[];
    down(down==0)=[];
    k=2002;
    if ~isempty(up)
        for i=1:length(up)
            
            upX1 = find(BmID(idx,:)==up(i));
            m=0;
            tempD = [];
            if isempty(down)
                continue
            end
            for j=1:length(down)
                downX1 = find(BmID(idx+1,:)==down(j));
                if ~isempty(intersect(upX1,downX1))
                    m=m+1;
                    tempD = [tempD down(j)];
                end
            end
            if m>=2
                BmID(BmID==up(i))=2001;
                for in=1:length(tempD(:))
                    BmID(BmID==tempD(in))=k;
                    k=k+1;
                end
            elseif m==1 && up(i)>=2000
                
                BmID(BmID==tempD(1))=k;
                k=k+1;
            end
        end
    end    
end

BmID(BmID<2000)=0;
BmID(BmID>2001)=2000;


BmID1 = BmI;


for idx=length(BmID1(:,1)):-1:2
    up=unique(BmID1(idx-1,:));
    down=unique(BmID(idx,:));
    
    up(up==0)=[];
    down(down==0)=[];
    
    if isempty(up) || isempty(down)
        continue
    end
    
    for i=1:length(down)
        
        if down(i)<2000
            continue
        end
        
        downX1 = find(BmID(idx,:)==down(i));
        for j=1:length(up)
            upX1 = find(BmID1(idx-1,:)==up(j));
            if ~isempty(intersect(upX1,downX1))
                BmID1(BmID1==up(j))=2000;
                cd=find(BmID==2001);
                BmID(BmID1>=2000)=2000;
                BmID(cd)=2001;                
            end
        end
    end        
end














for idx=2:length(BmIU(:,1))
    up=unique(BmIU(idx-1,:));
    down=unique(BmIU(idx,:));
    
    up(up==0)=[];
    down(down==0)=[];
    k=3002;
    if ~isempty(down)
        for i=1:length(down)
            downX1 = find(BmIU(idx,:)==down(i));
            m=0;
            tempD = [];
            if isempty(up)
                continue
            end
            for j=1:length(up)
                upX1 = find(BmIU(idx-1,:)==up(j));
                if ~isempty(intersect(downX1,upX1))
                    m=m+1;
                    tempD = [tempD up(j)];
                end
            end
            if m>=2
                BmIU(BmIU==down(i))=3001;
                for in=1:length(tempD(:))
                    BmIU(BmIU==tempD(in))=k;
                    k=k+1;
                end
            elseif m==1 && down(i)>=3000
                BmIU(BmIU==tempD(1))=k;
                k=k+1;
            end
        end
    end    
end

BmIU(BmIU<3000)=0;
BmIU(BmIU>3001)=3000;





BmIU1 = BmI;

for idx=1:length(BmIU1(:,1))-1
    up=unique(BmIU(idx,:));
    down=unique(BmIU1(idx+1,:));
    
    up(up==0)=[];
    down(down==0)=[];
    
    if isempty(up) || isempty(down)
        continue
    end
    
    for i=1:length(up)
        
        if up(i)<=3000
            continue
        end
        
        upX1 = find(BmIU(idx,:)==up(i));
        for j=1:length(down)
            downX1 = find(BmIU1(idx+1,:)==down(j));
            if ~isempty(intersect(upX1,downX1))
                BmIU1(BmIU1==down(j))=3000;
                cd=find(BmIU==3001);
                BmIU(BmIU1>=3000)=3000;
                BmIU(cd)=3001;
            end
        end
    end        
end

cd=find(BmID==0);
BmID(BmID<2001)=1;
BmID(cd)=0;
cd=find(BmIU==0);
BmIU(BmIU<3001)=1;
BmIU(cd)=0;

%figure
subplot(335)
imshow(BmID);

subplot(336)
imshow(BmIU);













k=1;
for i=1:size(BmID,1)
    
    idx = find(BmID(i,:)==2001);
    if isempty(idx)
        continue
    end
    b=find(diff(idx)>1);
    if isempty(b)
        BmID(i,idx)=k*1000;
        k=k+1;
    else
        for j=1:length(b)
            BmID(i,idx(1):idx(b(j)))=k*1000;
            k=k+1;
            BmID(i,idx(b(j)+1):idx(end))=k*1000;
            k=k+1;
        end
    end    
end








k=1;
for i=1:size(BmID,1)
    
    idx = find(BmID(i,:)==1);
    if isempty(idx)
        continue
    end
    b=find(diff(idx)>1);
    if isempty(b)
        BmID(i,idx)=k;
        k=k+1;
    elseif length(b)==1
        BmID(i,idx(1):idx(b(1)))=k;
        k=k+1;
        BmID(i,idx(b(1)+1):idx(end))=k;
        k=k+1;
    else
        BmID(i,idx(1):idx(b(1)))=k;
        k=k+1;
        for j=1:length(b)-1
            BmID(i,idx(b(j)+1):idx(b(j+1)))=k;
            k=k+1;            
        end
        BmID(i,idx(b(end)+1):idx(end))=k;
        k=k+1;
    end    
end

subplot(337)
imshow(BmID);

blk1 = BmID;

blk1 = zeros(size(BmID));

vlu=unique(unique(BmID));
vlu(vlu<1000)=[];
for i=1:length(vlu)
    
    blk = BmID;
    
    [mm,~]=find(blk==vlu(i));
    m=mm(1);
    A = find(blk(m,:)==vlu(i));
    B = find(blk(m+1,:)>=1);
    C = find(blk(m+1,:)<1000);
    D = intersect(B,C);
    if isempty(D)
        continue
    end
    IN = unique(blk(m+1,D));
    k=1;
    for j=1:length(IN)
        E = find(blk(m+1,:)==IN(j));
        if ~isempty(intersect(A,E))
            blk(m+1,E)=vlu(i)+k*10+j;
        end
    end
    
    
    
    for n=m+1:size(blk,1)
        ck=0;
        B = find(blk(n-1,:)>vlu(i));
        C = find(blk(n-1,:)<vlu(i)+1000);
        D = intersect(B,C);
        IN = unique(blk(n-1,D));
        jk=1;
        for j=1:length(IN)
            E = find(blk(n-1,:)==IN(j));
            
            B = find(blk(n,:)>=1);
            C = find(blk(n,:)<1000);
            D = intersect(B,C);
            IN1 = unique(blk(n,D));
            for jj=1:length(IN1)
                E1 = find(blk(n,:)==IN1(jj));
                if ~isempty(intersect(E,E1))
                       blk(n,E1)=vlu(i)+k*10+jk;
                        jk=jk+1;
                        ck=1;
                                       
                end
            end
            
        end
        if ck==1
            k=k+1;
            ck=0;
        end
    end
    blk1 = blk1 +blk;
end

blk1 = blk1 - (length(vlu)-1)*BmID;

%figure
subplot(338)
imshow(blk1);



blk1(blk1>=3000)=0;


subplot(339)
imshow(blk1);









