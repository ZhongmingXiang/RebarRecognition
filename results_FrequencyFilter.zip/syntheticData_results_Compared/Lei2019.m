clear all
close all
clc
warning off



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
Lei, W., Hou, F., Xi, J., Tan, Q., Xu, M., Jiang, X., ... & Gu, Q., Automatic hyperbola detection and fitting in GPR B-scan image. 
Automation in Construction. 106 (2019) pp.102839. https://doi.org/10.1016/j.autcon.2019.102839
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%


% file='gprMax_output\threedModeling\demoB1010009_744.jpg';
file='..\submission\RebarRecognition\results\syntheticData\21.jpg';
I = imread(file);

Itc=I(:,:,1);
ItcFP = imresize(Itc,[512,512]);   % original image


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% remove direct wave and cross rebar signals 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure('name', 'preprocess', 'visible','off');
%subplot(331)
imshow(ItcFP);

% b1 = [22 133 118 179];
% b2 = [88 173 163 239];
b3 = [141 134 329 179];
% b4 = [370 133 432 178];
% b5 = [374 175 436 220];
b6 = [315 162 478 214];

orgI=ItcFP;


figure('name', 'preprocess', 'visible','on');
imshow(orgI);
% rectangle('position',[b1(1) b1(2) b1(3)-b1(1) b1(4)-b1(2)],'edgecolor',[1 1 0]);
% rectangle('position',[b2(1) b2(2) b2(3)-b2(1) b2(4)-b2(2)],'edgecolor',[1 1 0]);
rectangle('position',[b3(1) b3(2) b3(3)-b3(1) b3(4)-b3(2)],'edgecolor',[1 1 0]);
% rectangle('position',[b4(1) b4(2) b4(3)-b4(1) b4(4)-b4(2)],'edgecolor',[1 1 0]);
% rectangle('position',[b5(1) b5(2) b5(3)-b5(1) b5(4)-b5(2)],'edgecolor',[1 1 0]);
rectangle('position',[b6(1) b6(2) b6(3)-b6(1) b6(4)-b6(2)],'edgecolor',[1 1 0]);
saveas(gcf,'..\submission\RebarRecognition\results\syntheticData_results_Compared\Lei2019\21_boxes.jpg')
%%% 1

% ItF = ItcFP(b1(2):b1(4),b1(1):b1(3));
% BmI1 = Lei2019_function(ItF);
% Line1=[];
% for i=1:size(BmI1,2)
%     m=find(BmI1(:,i)>0);
%     if ~isempty(m)
%         Line1 = [Line1;i,mean(m)];
%     end
% end
% Line1(:,1)=Line1(:,1)+b1(1);
% Line1(:,2)=Line1(:,2)+b1(2);

% ItF = ItcFP(b2(2):b2(4),b2(1):b2(3));
% BmI1 = Lei2019_function(ItF);
% Line2=[];
% for i=1:size(BmI1,2)
%     m=find(BmI1(:,i)>0);
%     if ~isempty(m)
%         Line2 = [Line2;i,mean(m)];
%     end
% end
% Line2(:,1)=Line2(:,1)+b2(1);
% Line2(:,2)=Line2(:,2)+b2(2);
% 
ItF = ItcFP(b3(2):b3(4),b3(1):b3(3));
BmI1 = Lei2019_function(ItF);
Line3=[];
for i=1:size(BmI1,2)
    m=find(BmI1(:,i)>0);
    if ~isempty(m)
        Line3 = [Line3;i,mean(m)];
    end
end
Line3(:,1)=Line3(:,1)+b3(1);
Line3(:,2)=Line3(:,2)+b3(2);

% ItF = ItcFP(b4(2):b4(4),b4(1):b4(3));
% BmI1 = Lei2019_function(ItF);
% Line4=[];
% for i=1:size(BmI1,2)
%     m=find(BmI1(:,i)>0);
%     if ~isempty(m)
%         Line4 = [Line4;i,mean(m)];
%     end
% end
% Line4(:,1)=Line4(:,1)+b4(1);
% Line4(:,2)=Line4(:,2)+b4(2);

% ItF = ItcFP(b5(2):b5(4),b5(1):b5(3));
% BmI1 = Lei2019_function(ItF);
% Line5=[];
% for i=1:size(BmI1,2)
%     m=find(BmI1(:,i)>0);
%     if ~isempty(m)
%         Line5 = [Line5;i,mean(m)];
%     end
% end
% Line5(:,1)=Line5(:,1)+b5(1);
% Line5(:,2)=Line5(:,2)+b5(2);
% 
ItF = ItcFP(b6(2):b6(4),b6(1):b6(3));
BmI1 = Lei2019_function(ItF);
Line6=[];
for i=1:size(BmI1,2)
    m=find(BmI1(:,i)>0);
    if ~isempty(m)
        Line6 = [Line6;i,mean(m)];
    end
end
Line6(:,1)=Line6(:,1)+b6(1);
Line6(:,2)=Line6(:,2)+b6(2);



figure
imshow(ItcFP);hold on
% p1 = polyfit(Line1(:,1),Line1(:,2),2);
% x1 = linspace(min(Line1(:,1)),max(Line1(:,1)));
% f1 = polyval(p1,x1);
% plot(x1,f1,'r','linewidth',2),hold on;

% p1 = polyfit(Line2(:,1),Line2(:,2),2);
% x1 = linspace(min(Line2(:,1)),max(Line2(:,1)));
% f1 = polyval(p1,x1);
% plot(x1,f1,'r','linewidth',2),hold on;
% 
p1 = polyfit(Line3(:,1),Line3(:,2),2);
x1 = linspace(min(Line3(:,1)),max(Line3(:,1)));
f1 = polyval(p1,x1);
plot(x1,f1,'r','linewidth',2),hold on;
% 
% p1 = polyfit(Line4(:,1),Line4(:,2),2);
% x1 = linspace(min(Line4(:,1)),max(Line4(:,1)));
% f1 = polyval(p1,x1);
% plot(x1,f1,'r','linewidth',2),hold on;

% p1 = polyfit(Line5(:,1),Line5(:,2),2);
% x1 = linspace(min(Line5(:,1)),max(Line5(:,1)));
% f1 = polyval(p1,x1);
% plot(x1,f1,'r','linewidth',2),hold on;
% 
p1 = polyfit(Line6(:,1),Line6(:,2),2);
x1 = linspace(min(Line6(:,1)),max(Line6(:,1)));
f1 = polyval(p1,x1);
plot(x1,f1,'r','linewidth',2),hold on;
saveas(gcf,'..\submission\RebarRecognition\results\syntheticData_results_Compared\Lei2019\21.jpg')




